package herisson.application.br.speakforme;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class EdicaoExpressao extends AppCompatActivity implements AdapterView.OnItemSelectedListener {



    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;

    @Override
    protected void onCreate(Bundle savedInstanceStated) {
        super.onCreate(savedInstanceStated);
        setContentView(R.layout.activity_edit_expressoes);

        // Spinner List

        Spinner spinnerIdioma = findViewById(R.id.spinnerIdioma);
        Spinner spinnerExpressao = findViewById(R.id.spinnerExpressao);
        Spinner spinnerCategoria = findViewById(R.id.spinnerCategoria);

        // Idioma

        ArrayAdapter<CharSequence> adapterIdioma = ArrayAdapter.createFromResource(this, R.array.Idiomas, android.R.layout.simple_spinner_item);
        adapterIdioma.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerIdioma.setAdapter(adapterIdioma);
        spinnerIdioma.setOnItemSelectedListener(this);

        // Expressão

        ArrayAdapter<CharSequence> adapterExpressao = ArrayAdapter.createFromResource(this, R.array.Expressao, android.R.layout.simple_spinner_item);
        adapterExpressao.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerExpressao.setAdapter(adapterExpressao);
        spinnerExpressao.setOnItemSelectedListener(this);

        // Categoria

        ArrayAdapter<CharSequence> adapterCategoria = ArrayAdapter.createFromResource(this, R.array.Categoria, android.R.layout.simple_spinner_item);
        adapterCategoria.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategoria.setAdapter(adapterCategoria);
        spinnerCategoria.setOnItemSelectedListener(this);


        // Action Bar & Navigation Bar

        drawerLayout = (DrawerLayout)findViewById(R.id.drawerLayout);
        toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }

    // Spinner Item

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // String text = parent.getItemAtPosition(position).toString();
        // Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    // Action Bar & Navigation Bar

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        if(toggle.onOptionsItemSelected(item)){

            return true;

        }

        return super.onOptionsItemSelected(item);
    }

    /*
    @Override
    public boolean onMenuItemSelected(int featuredId, MenuItem item){

        switch (item.getItemId()){

            case R.id.menuInserirExpressao:
                startActivity(new Intent(this, InsercaoExpressao.class));
                return true;

            case R.id.menuInserirIdioma:
                startActivity(new Intent(this, InsercaoIdiomas.class));
                return true;

            case R.id.menuEditExpressao:
                startActivity(new Intent(this, EdicaoExpressao.class));
                return true;

            case R.id.menuEditIdioma:
                startActivity(new Intent(this, EdicaoIdiomas.class));
                return true;

            case R.id.menuConfiguracoes:
                startActivity(new Intent(this, EdicaoUsuario.class));
                return true;

            case R.id.menuSair:
                startActivity(new Intent(this, MainActivity.class));
                return true;

            default:
                return super.onMenuItemSelected(featuredId, item);



        }

    }
    */
}
