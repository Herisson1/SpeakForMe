package herisson.application.br.speakforme;


import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class HomeAdmin extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_adm);;



        CardView cvEdicaoIdioma = (CardView) findViewById(R.id.cvEdicaoIdioma);
        CardView cvEdicaoExpressao = (CardView) findViewById(R.id.cvEdicaoExpressao);
        CardView cvInsercaoIdioma = (CardView) findViewById(R.id.cvInsercaoIdioma);
        CardView cvInsercaoExpressao = (CardView) findViewById(R.id.cvInsercaoExpressao);

        cvEdicaoIdioma.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent (HomeAdmin.this , EdicaoIdiomas.class);
                startActivity(intent);
            }
        });

        cvEdicaoExpressao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeAdmin.this, EdicaoExpressao.class);
                startActivity(intent);
            }
        });

        cvInsercaoIdioma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (HomeAdmin.this, InsercaoIdiomas.class);
                startActivity(intent);
            }
        });

        cvInsercaoExpressao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (HomeAdmin.this, InsercaoExpressao.class);
                startActivity(intent);
            }
        });


        drawerLayout = (DrawerLayout)findViewById(R.id.drawerLayout);
        toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        if(toggle.onOptionsItemSelected(item)){

            return true;

        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
