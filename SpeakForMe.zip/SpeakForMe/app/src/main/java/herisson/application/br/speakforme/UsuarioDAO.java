package herisson.application.br.speakforme;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.List;

public class UsuarioDAO {

    private SQLiteDatabase DB;


    public UsuarioDAO (Context context){
        BDCore auxDB = new BDCore(context);
        db = auxDB.getWritableDatabase();
    }

    public void inserir(Usuario usuario){
        ContentValues valores = new ContentValues();

        valores.put("nome", usuario.getNome());
        valores.put("email", usuario.getEmail());
        valores.put("senha", usuario.getSenha());
        valores.put("idioma", usuario.getIdioma());

        db.insert("usuario", null, valores);
    }

    public void atualizar(Usuario usuario){
        ContentValues valores = new ContentValues();

        valores.put("nome", usuario.getNome());
        valores.put("email", usuario.getEmail());
        valores.put("senha", usuario.getSenha());
        valores.put("idioma", usuario.getIdioma());

        db.update("usuario", valores, "_id = ?", new String[]{""+usuario.getId()});
    }

    public void deletar(Usuario usuario){
       db.delete("usuario", "_id = "+usuario.getId(), null);
    }

    public List<Usuario> buscar(){
        String[] colunas = new String[]{"_id", "nome", "email"};
        Cursor cursor = db.query("usuario", colunas, null, null, null, null, "nome ASC");
    }


}
