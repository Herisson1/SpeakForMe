package herisson.application.br.speakforme;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.net.PasswordAuthentication;

public class CadastroUsuarioActivity extends Activity {

    private EditText nome;
    private EditText email;
    private EditText idioma;
    private EditText senha;
    private EditText confirmarSenha;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_usuario);

        nome = (EditText) findViewById(R.id.nomeUsuario);
        email = (EditText) findViewById(R.id.emailUsuario);
        idioma = (EditText) findViewById(R.id.idiomaUsuario);
        senha = (EditText) findViewById(R.id.senhaUsuario);
        confirmarSenha = (EditText) findViewById(R.id.confSenhaUsario);



        final Button btHome = (Button) findViewById(R.id.btHome);
        final Button btCadUsuario = (Button) findViewById(R.id.btCadUsuario);

        btHome.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent (CadastroUsuarioActivity.this , MainActivity.class);
                startActivity(intent);
            }
        });

        btCadUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CadastroUsuarioActivity.this, HomeAdmin.class);
                startActivity(intent);

            }
        });



    }

}

